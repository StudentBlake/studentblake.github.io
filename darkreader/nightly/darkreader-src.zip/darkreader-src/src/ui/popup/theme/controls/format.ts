export function formatPercent(v: number) {
    return `${v}%`;
}
