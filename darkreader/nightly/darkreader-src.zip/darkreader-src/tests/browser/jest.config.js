module.exports = {
    projects: [
        'tests/browser/jest.config.chrome.js',
        'tests/browser/jest.config.firefox.js',
    ],
};
