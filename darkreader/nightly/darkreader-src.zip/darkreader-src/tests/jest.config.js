module.exports = {
    projects: [
        'tests/config/jest.config.js',
        'tests/utils/jest.config.js',
    ],
    verbose: true,
};
